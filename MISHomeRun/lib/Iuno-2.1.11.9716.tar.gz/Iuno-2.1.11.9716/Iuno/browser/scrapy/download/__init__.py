#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: __init__.py 9699 2016-07-03 10:27:21Z Eric $
#
# Copyright (c) 2016 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Eric $
# $Date: 2016-07-03 18:27:21 +0800 (週日, 03 七月 2016) $
# $Revision: 9699 $

from Iuno.browser.scrapy.download.BrowserDownloader import BrowserDownloadHandler