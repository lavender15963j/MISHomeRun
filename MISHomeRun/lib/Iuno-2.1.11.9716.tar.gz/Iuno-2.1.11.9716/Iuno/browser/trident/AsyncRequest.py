#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: AsyncRequest.py 9621 2016-04-06 13:36:10Z Eric $
#
# Copyright (c) 2012 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Eric $
# $Date: 2016-04-06 21:36:10 +0800 (週三, 06 四月 2016) $
# $Revision: 9621 $
"""
AsyncRequest for Trident implementation.
"""

import sys
import os
import platform
import threading

from .. import AsyncRequest

class Impl(AsyncRequest.AsyncRequest):
    """
    AsyncRequest for Trident implementation.
    """
