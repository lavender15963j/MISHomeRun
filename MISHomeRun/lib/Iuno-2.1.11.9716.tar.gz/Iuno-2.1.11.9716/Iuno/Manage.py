#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: Manage.py 9471 2015-11-06 07:10:07Z Eric $
#
# Copyright (c) 2015 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Eric $ (last)
# $Date: 2015-11-06 15:10:07 +0800 (週五, 06 十一月 2015) $
# $Revision: 9471 $

import os
import sys

if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "IunoSettings")

    from django.core.management import execute_from_command_line

    execute_from_command_line(sys.argv)
