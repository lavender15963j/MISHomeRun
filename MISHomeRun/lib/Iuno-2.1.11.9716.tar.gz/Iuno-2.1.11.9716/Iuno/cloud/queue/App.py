#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: __init__.py 9455 2015-10-24 08:45:55Z Judy $
#
# Copyright (c) 2015 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Judy $ (last)
# $Date: 2015-10-24 16:45:55 +0800 (�g��, 24 �Q�� 2015) $
# $Revision: 9455 $

from __future__ import absolute_import
 
import os
 
from celery import Celery
 
from Iuppiter import Configure
 
settings = Configure.getSettings()
projectName = settings.strip('.settings')

if not projectName:
    projectName = os.getcwd().split(os.sep)[-1]

os.environ.setdefault('DJANGO_SETTINGS_MODULE', settings)

app = Celery(projectName)
app.config_from_object(settings)
