#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: Util.py 9438 2015-09-25 07:43:20Z Eric $
#
# Copyright (c) 2016 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Eric $
# $Date: 2015-09-25 15:43:20 +0800 (Fri, 25 Sep 2015) $
# $Revision: 9438 $

import os

from django.test import TestCase

from Iuno import attachSettings

class TestAttachSettings(TestCase):

    REQUIRED_SETTINGS = {
        'ROOT_URLCONF' : "urls",
        'SECRET_KEY' : "456456",
        '__file__' : os.path.dirname(
            os.path.dirname(os.path.abspath(__file__)))
    }

    def testPopulateEnvToSettings(self):
        """
        Test for populateEnvToSettings function, see #2747.        
        """
        settings = TestAttachSettings.REQUIRED_SETTINGS.copy()
        
        attachSettings(settings)        
        self.assertEqual(settings['DEBUG'], True)
        
        os.environ['DEBUG'] = 'false'
        attachSettings(settings)    
        self.assertEqual(settings['DEBUG'], False)        
        
        os.environ['DEBUG'] = 'True'
        attachSettings(settings)    
        self.assertEqual(settings['DEBUG'], True)        
        
        os.environ.pop('DEBUG')
        
        settings = TestAttachSettings.REQUIRED_SETTINGS.copy()
        os.environ['SERVER_MODE'] = 'production'        
        attachSettings(settings)    
        self.assertEqual(settings['DEBUG'], False)   
        from Iuno import PRODUCTION
        self.assertEqual(settings['SERVER_MODE'], PRODUCTION)
        
        os.environ.pop('SERVER_MODE')
        
        settings = TestAttachSettings.REQUIRED_SETTINGS.copy()
        os.environ['ADMIN_EMAIL'] = 'devops@nuwainfo.com'
        os.environ['ALLOWED_HOST'] = '.example.com'
        attachSettings(settings)    
        self.assertEqual(settings['ADMINS'][-1], 
            ('devops', os.environ['ADMIN_EMAIL']))
        self.assertTrue(os.environ['ALLOWED_HOST'] in settings['ALLOWED_HOSTS'])
        
        settings = TestAttachSettings.REQUIRED_SETTINGS.copy()
        os.environ['DATABASE_URL'] = (
            'postgres://'
            'user3123:passkja83kd8@'
            'ec2-117-21-174-214.compute-1.amazonaws.com:6212/db982398'
        )
        attachSettings(settings)    
        self.assertEqual(settings['DATABASES']['default'], {
            'ENGINE': 'django.db.backends.postgresql_psycopg2',
            'NAME': 'db982398',
            'USER': 'user3123',
            'PASSWORD': 'passkja83kd8',
            'HOST': 'ec2-117-21-174-214.compute-1.amazonaws.com',
            'PORT': 6212,   
        })        
        
        os.environ.update({
            'DEFAULT_FROM_EMAIL': 'devops@nuwainfo.com',
            'EMAIL_PORT': '25',
            'EMAIL_USE_TLS': 'False',
        })
        attachSettings(settings)    
        self.assertEqual(settings['DEFAULT_FROM_EMAIL'], 
                         os.environ['DEFAULT_FROM_EMAIL'])
        self.assertEqual(settings['EMAIL_PORT'], eval(os.environ['EMAIL_PORT']))
        self.assertEqual(settings['EMAIL_USE_TLS'], False)
        
        settings = TestAttachSettings.REQUIRED_SETTINGS.copy()
        os.environ['IUNO_CLOUD_ENABLE'] = 'True'
        os.environ['IUNO_CLOUD_SERVICES'] = "()"
        attachSettings(settings)    
        self.assertEqual(settings['IUNO_CLOUD_ENABLE'], True)
        self.assertEqual(settings['IUNO_CLOUD_SERVICES'], ())
    
    def testEmptyTemplatesSettings(self):
    
        settingsContent = TestAttachSettings.REQUIRED_SETTINGS.copy()
        settingsContent.update({
                               
            'INSTALLED_APPS' : (
                'django.contrib.admin',
                'django.contrib.auth',
                'django.contrib.contenttypes',
                'django.contrib.sessions',
                'django.contrib.messages',
                'django.contrib.staticfiles',
            ),
            'MIDDLEWARE_CLASSES' : (
                'django.contrib.sessions.middleware.SessionMiddleware',
                'django.middleware.common.CommonMiddleware',
                'django.middleware.csrf.CsrfViewMiddleware',
                'django.contrib.auth.middleware.AuthenticationMiddleware',
                ('django.contrib.auth.middleware.'
                 'SessionAuthenticationMiddleware'),
                'django.contrib.messages.middleware.MessageMiddleware',
                'django.middleware.clickjacking.XFrameOptionsMiddleware',
                'django.middleware.security.SecurityMiddleware',
            ),
        })

        attachSettings(settingsContent)
            
        templatesSettings = {
            'TEMPLATES' : [
                {
                    'BACKEND': ('django.template.backends.django.'
                                'DjangoTemplates'),
                    'DIRS': [],
                    'APP_DIRS': True,
                    'OPTIONS': {
                        'context_processors': [
                            'django.template.context_processors.debug',
                            'django.template.context_processors.request',
                            'django.contrib.auth.context_processors.auth',
                            ('django.contrib.messages.context_processors.'
                            'messages'),
                        ],
                    },
                },
            ],
        }
        
        self.assertEqual(settingsContent['TEMPLATES'],
                         templatesSettings['TEMPLATES'])
        
    def testMissingTemplatesSettings(self):
    
        settingsContent = TestAttachSettings.REQUIRED_SETTINGS.copy()
        settingsContent.update({
                               
            'INSTALLED_APPS' : (
                'django.contrib.admin',
                'django.contrib.auth',
                'django.contrib.contenttypes',
                'django.contrib.sessions',
                'django.contrib.messages',
                'django.contrib.staticfiles',
            ),
            'MIDDLEWARE_CLASSES' : (
                'django.contrib.sessions.middleware.SessionMiddleware',
                'django.middleware.common.CommonMiddleware',
                'django.middleware.csrf.CsrfViewMiddleware',
                'django.contrib.auth.middleware.AuthenticationMiddleware',
                ('django.contrib.auth.middleware.'
                 'SessionAuthenticationMiddleware'),
                'django.contrib.messages.middleware.MessageMiddleware',
                'django.middleware.clickjacking.XFrameOptionsMiddleware',
                'django.middleware.security.SecurityMiddleware',
            ),
            'TEMPLATES' : [
                {
                    'BACKEND': ('django.template.backends.django.'
                                'DjangoTemplates'),
                },
            ],                         
        })
        
        
        settingsContent['__file__'] = os.path.dirname(
            os.path.dirname(os.path.abspath(__file__)))
            
        attachSettings(settingsContent)
            
        templatesSettings = {
            'TEMPLATES' : [
                {
                    'BACKEND': ('django.template.backends.django.'
                                'DjangoTemplates'),
                    'DIRS': [],
                    'APP_DIRS': True,
                    'OPTIONS': {
                        'context_processors': [
                            'django.template.context_processors.debug',
                            'django.template.context_processors.request',
                            'django.contrib.auth.context_processors.auth',
                            ('django.contrib.messages.context_processors.'
                             'messages'),
                        ],
                    },
                },
            ],
        }
        
        self.assertEqual(settingsContent['TEMPLATES'],
                         templatesSettings['TEMPLATES'])
