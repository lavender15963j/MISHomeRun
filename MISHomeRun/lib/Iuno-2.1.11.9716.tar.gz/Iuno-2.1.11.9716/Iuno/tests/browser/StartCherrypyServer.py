#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: StartCherrypyServer.py 9621 2016-04-06 13:36:10Z Eric $
#
# Copyright (c) 2016 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Eric $
# $Date: 2016-04-06 21:36:10 +0800 (週三, 06 四月 2016) $
# $Revision: 9621 $

import os
import cherrypy

class Root(object): 
    pass

PATH = os.path.abspath(os.path.join(os.path.dirname( __file__ ), '..', 
                                            'static-files'))
cherrypy.config.update({"server.socket_port": 8000})
cherrypy.quickstart(cherrypy.Application(Root()), '/', config={
    '/': {
            'tools.staticdir.on': True,
            'tools.staticdir.dir': PATH,
            'tools.staticdir.index': 'Index.html',
        },
})
