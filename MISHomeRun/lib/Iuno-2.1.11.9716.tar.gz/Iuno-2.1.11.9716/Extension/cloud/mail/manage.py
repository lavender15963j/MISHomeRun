#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: manage.py 5524 2011-07-10 11:09:53Z Bear $
#
# Copyright (c) 2011 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Bear $
# $Date: 2011-07-10 19:09:53 +0800 (週日, 10 七月 2011) $
# $Revision: 5524 $

import os
import sys

if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")

    from django.core.management import execute_from_command_line

    execute_from_command_line(sys.argv)
