This project should be run at cloud instance (Amazon EC2 instance) with this
command to handle mail with Amazon SES:

celery -A Iuno.cloud.queue.App worker -l info -Q mail --autoscale=10

or daemonize it:

http://docs.celeryproject.org/en/latest/cookbook/daemonizing.html

NOTE: there is a bug in windows, you must specify settings to run celeryd:
(http://stackoverflow.com/questions/3323125/celery-django-cant-find-settings)

python manage.py celeryd -Q mail --autoscale=10 --settings=settings

== Requirement ==

1. To run this project inside Amazon EC2, you must save a .boto file under this
   folder for authentication.

2. Set up permission to allow user celery to write log file and sent html files
   to sent folder:
   chmod 666 sent.log
   chmod 777 sent

3. Edit settings.py to change SERVER_MODE = PRODUCTION

== Test ==
python manage.py shell

> from django.core.mail import send_mail
> send_mail('Subject here', 'Here is the message.', 'service@tracedig.com',
            ['bear@tracedig.com'], fail_silently=False)
