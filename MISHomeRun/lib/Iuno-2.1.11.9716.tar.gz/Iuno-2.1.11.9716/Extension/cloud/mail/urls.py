#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: urls.py 8762 2013-01-31 09:36:30Z Bear $
#
# Copyright (c) 2013 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Bear $
# $Date: 2013-01-31 17:36:30 +0800 (週四, 31 一月 2013) $
# $Revision: 8762 $

from django.conf.urls import patterns
from django.conf.urls import include, url
# Required import for 404 handle.
from django.conf.urls import handler404
# Required import for 500 handle.
from django.conf.urls import handler500
from django.views.generic.base import TemplateView as direct_to_template

from django.contrib import admin
admin.autodiscover()

import settings

urlpatterns = patterns('')

from Iuno import Patch
Patch.attachURLs(settings, urlpatterns)

urlpatterns += patterns('',
    (r'^i18n/', include('Iuppiter.i18n.urls')),
    (r'^admin/', include(admin.site.urls)),
)
