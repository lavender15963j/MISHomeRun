This project should be run at cloud instance (e.g. Amazon EC2 instance) with 
this command to handle Iuno.browser's requests:

celery -A Iuno.cloud.queue.App worker -l info -Q browser --autoscale=10

or daemonize it:

http://docs.celeryproject.org/en/latest/cookbook/daemonizing.html

== Requirement ==

1. Edit settings.py to change SERVER_MODE = PRODUCTION

== Test ==
python manage.py shell

> from Iuno.browser import get
> get('http://www.google.com.tw/', engine='curl', async=True)
