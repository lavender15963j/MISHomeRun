#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: urls.py 9626 2016-04-10 14:52:18Z Eric $
#
# Copyright (c) 2012 Nuwa Information Co., Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Eric $
# $Date: 2016-04-10 22:52:18 +0800 (週日, 10 四月 2016) $
# $Revision: 9626 $

from django.conf.urls.defaults import patterns
from django.conf.urls.defaults import include, url
# Required import for 404 handle.
from django.conf.urls.defaults import handler404
# Required import for 500 handle.
from django.conf.urls.defaults import handler500
from django.views.generic.simple import direct_to_template

from django.contrib import admin
admin.autodiscover()

import settings

urlpatterns = patterns('')

from Iuno import Patch
Patch.attachURLs(settings, urlpatterns)
handler500 = Patch.handle500

urlpatterns += patterns('',
    (r'^i18n/', include('Iuppiter.i18n.urls')),
    (r'^admin/', include(admin.site.urls)),
)
