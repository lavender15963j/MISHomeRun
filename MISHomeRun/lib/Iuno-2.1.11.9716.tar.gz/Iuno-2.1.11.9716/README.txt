Common code base for all Nuwa related code.

== Naming ==
Juno (Latin pronunciation: /juːnoː/) was an ancient Roman goddess, the
protector and special counselor of the state. She is a daughter of Saturn and
sister (but also the wife) of the chief god Jupiter and the mother of Mars,
Minerva and Vulcan. Her Greek equivalent is Hera.

As the patron goddess of Rome and the Roman empire she was called Regina
("queen") and, together with Jupiter and Minerva, was worshipped as a triad on
the Capitol (Juno Capitolina) in Rome.

As the great Juno Moneta (which the ancients interpreted as "the one who warns";
this traditional etymology is badly formed, but has not been replaced) she
guarded over the finances of the empire and had a temple on the Arx (one of two
Capitoline hills), which was the Mint. She was also worshipped in many other
cities, where temples were built in her honor.

Every year, on the first of March, women held a festival in honor of Juno
called the Matronalia. On this day, lambs and other cattle were sacrificed in
her honor. Another festival called the Nonae Caprotinae ("The Nones of the
Wild Fig") was held on July 7. Juno is the patroness of marriage, and many
people believe that the most favorable time to marry is June, the month named
after the goddess. Lucina was an epithet for Juno as "she who brings children
into light."

Juno's own warlike aspect among the Romans is apparent in her attire. She often
appeared armed and wearing a goatskin cloak, which was the garment favoured by
Roman soldiers on campaign. This warlike aspect was assimilated from the Greek
goddess Athena, whose goatskin was called the 'aegis'.

Reference source:
http://en.wikipedia.org/wiki/Juno_%28mythology%29
http://zh.wikipedia.org/wiki/%E6%9C%B1%E8%AB%BE_%28%E7%A5%9E%E8%A9%B1%29

== Upload ==
Upload release to Nuwa's PYPI:

python setup.py sdist upload -r dev

Reference:
http://doc.devpi.net/latest/userman/devpi_misc.html#using-plain-setup-py-for-uploading
