﻿Common library for all code.

== Naming ==

In Roman mythology, Jupiter (Iuppiter in Latin) held the same role as Zeus in
the Greek pantheon.
He was called Juppiter Optimus Maximus Soter (Jupiter Best, Greatest, Savior);
as the patron deity of the Roman state, he ruled over laws and social order.
He was the chief god of the Capitoline Triad, with Juno and Minerva.

Iuppiter, originating in a vocative compound derived from archaic Latin Iovis
and pater (Latin for father), was also used as the nominative case.
Jove[1] is a less common English formation based on Iov-, the stem of oblique
cases of the Latin name. Additionally, linguistic studies identify his name as
deriving from the Indo-European compound *dy��us- p��ter- ("O Father God"), the
Indo-European deity from whom also derive the Germanic *Tiwaz (from whose name
comes the word Tuesday), the Greek Zeus, and the Vedic equivalent, Dyaus Pita.

The name of the god was also adopted as the name of the planet Jupiter,
and was the original namesake of Latin forms of the weekday known in English as
Thursday.[2] Originally called Iovis Dies in Latin, one can see the root of
Thursday various modern Romance languages: jeudi in French, jueves in
Castillian, gioved�� in Italian, and dijous in Catalan.

Please make sure the .pypirc file under your home directory, or you will get 
"unsupported schema" error.

Reference source:
http://en.wikipedia.org/wiki/Jupiter_%28mythology%29
http://zh.wikipedia.org/wiki/%E6%9C%B1%E5%BA%87%E7%89%B9

== Upload ==
Upload release to Nuwa's PYPI:

python setup.py sdist upload -r dev

Reference:
http://doc.devpi.net/latest/userman/devpi_misc.html#using-plain-setup-py-for-uploading
