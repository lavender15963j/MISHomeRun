#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: SettingsTest.py 9610 2016-03-30 10:07:34Z Judy $
#
# Copyright (c) 2016 Nuwa Information Co., Ltd, and individual contributors.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#
#   2. Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#
#   3. Neither the name of Nuwa Information nor the names of its contributors
#      may be used to endorse or promote products derived from this software
#      without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# $Author: Judy $ (last)
# $Date: 2016-03-30 18:07:34 +0800 (週三, 30 三月 2016) $
# $Revision: 9610 $

from Iuppiter import test as TestUtil
from Iuppiter import tests
from Iuppiter.extension.templatetags.Settings import settings

import unittest

from django.test.client import Client
from django.conf.urls import patterns

class SettingsTest(unittest.TestCase):
    """
    Test case for Settings.
    """

    def setUp(self):
        self.client = Client()

    def testSettings(self):
        urlpatterns = tests.urlpatterns
        
        from Iuppiter.extension.views import view
        
        @view('SettingsTest.html')
        def testSettings(request):
            return {}
        
        testUrl = '/test'
        
        urlpatterns += patterns('',
            (r'^%s$' % testUrl[1:], testSettings),)
        
        response = self.client.post(testUrl)  
        self.assertTrue('test' in response.content)

if __name__ == '__main__':
    unittest.main()
