#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: EncodingTest.py 9467 2015-11-02 09:20:57Z Eric $
#
# Copyright (c) 2015 Nuwa Information Co., Ltd, and individual contributors.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#
#   2. Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#
#   3. Neither the name of Nuwa Information nor the names of its contributors
#      may be used to endorse or promote products derived from this software
#      without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# $Author: Eric $ (last)
# $Date: 2015-11-02 17:20:57 +0800 (週一, 02 十一月 2015) $
# $Revision: 9467 $
"""
Test all encoding functions.
"""

from Iuppiter import test

test.chdirToRootDir()

import unittest

class EncodingTest(unittest.TestCase):
    """
    Test case for Encoding.
    """

    def testUtf8(self):
        """
        Test for utf8 function.
        """
        from Iuppiter.Encoding import utf8

        msg = ("\xa4@\xa6\xb8\xa5u\xaf\xe0\xa5\xce\xa4@\xad\xd3\xb3q\xb0T"
               "\xba\xdd\xa6\xec\xa7} (\xb3q\xb0T\xa8\xf3\xa9w/\xba\xf4\xb8"
               "\xf4\xa6\xec\xa7}/\xb3s\xb1\xb5\xb0\xf0)\xa1C")

        self.assertEqual(utf8(msg), (
            '\xe4\xb8\x80\xe6\xac\xa1\xe5\x8f\xaa\xe8\x83\xbd\xe7\x94\xa8'
            '\xe4\xb8\x80\xe5\x80\x8b\xe9\x80\x9a\xe8\xa8\x8a\xe7\xab\xaf'
            '\xe4\xbd\x8d\xe5\x9d\x80 (\xe9\x80\x9a\xe8\xa8\x8a\xe5\x8d\x94'
            '\xe5\xae\x9a/\xe7\xb6\xb2\xe8\xb7\xaf\xe4\xbd\x8d\xe5\x9d\x80/'
            '\xe9\x80\xa3\xe6\x8e\xa5\xe5\x9f\xa0)\xe3\x80\x82'))

    def test_unicode(self):
        """
        Test for _unicode function.
        """
        from Iuppiter.Encoding import _unicode

        # Simplified chinese.
        s = '2009-11-18 \xd0\xc7\xc6\xda\xc8\xfd 22:09:30'
        try:
            _unicode(s, True)
        except:
            pass

        self.assertEqual(_unicode(s, encodings=('gb2312',)),
                         u'2009-11-18 \u661f\u671f\u4e09 22:09:30')

if __name__ == '__main__':
    unittest.main()
