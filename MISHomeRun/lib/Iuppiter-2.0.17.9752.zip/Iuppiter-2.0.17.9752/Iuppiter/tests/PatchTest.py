#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: PatchTest.py 9536 2016-01-05 08:43:22Z Judy $
#
# Copyright (c) 2015 Nuwa Information Co., Ltd, and individual contributors.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#
#   2. Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#
#   3. Neither the name of Nuwa Information nor the names of its contributors
#      may be used to endorse or promote products derived from this software
#      without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# $Author: Judy $ (last)
# $Date: 2016-01-05 16:43:22 +0800 (週二, 05 一月 2016) $
# $Revision: 9536 $

import os
import unittest
import shutil
import sys

from Iuppiter.Util import extractZip
from Iuppiter import Patch
from Iuppiter import DistUtil 

class TestPatch(unittest.TestCase):
     
    sitePackagesDir = DistUtil.getSitePackagesDir()
    testPackageDir = os.path.join(sitePackagesDir, "PatchTestPackage")
      
    def setUp(self):
        dir = os.path.abspath(os.path.dirname(__file__))
        testPackageZipFile = os.path.join(dir, "TestData", 
                                          "PatchTestPackage.zip")
        shutil.copy(testPackageZipFile, self.sitePackagesDir)
        zipFile = os.path.join(self.sitePackagesDir, "PatchTestPackage.zip")        
        extractZip(zipFile, self.sitePackagesDir)
  
    def testPatch(self):
        #before patch
#         import PatchTestPackage.PatchTestModule as patch    
#      
#         funReplaceResult = patch.testFunReplace()
#         self.assertEqual(funReplaceResult, False)
#               
#         funBodyResult = patch.testFunBody()
#         self.assertEqual(funBodyResult, False)
#               
#         funBeforeResult = patch.testFunBefore()
#         self.assertEqual(funBeforeResult, None)
#               
#         funAfterResult = patch.testFunAfter()
#         self.assertEqual(funAfterResult, None)
#               
#         clsReplaceResult = patch.TestReplaceClass()
#         self.assertEqual(clsReplaceResult.patch, False)
#               
#         clsBodyResult = patch.TestBodyClass()
#         self.assertEqual(clsBodyResult.patch, False)
#               
#         clsBeforeResult = patch.TestBeforeClass()
#         self.assertEqual(clsBeforeResult.test(), False)
#               
#         clsAfterResult = patch.TestAfterClass()
#         self.assertEqual(clsAfterResult.patch, False)          
#         sys.modules.pop("PatchTestPackage.PatchTestModule")
        
        #patch
        rootDir = os.path.dirname(__file__)
        patchDir = os.path.join(rootDir, 'TestData', 'Patch')
        Patch.patch(patchDir, strict=False)            
        import PatchTestPackage.PatchTestModule as patch  
               
        funReplaceResult = patch.functionReplace()
        self.assertEqual(funReplaceResult, True)
          
        funBodyResult = patch.testFunBody()
        self.assertEqual(funBodyResult, True)
          
        funBeforeResult = patch.testFunBefore()
        self.assertEqual(funBeforeResult, True)
          
        funAfterResult = patch.testFunAfter()
        self.assertEqual(funAfterResult, True)
          
        clsReplaceResult = patch.ReplaceClass()
        self.assertEqual(clsReplaceResult.patch, True)
          
        clsBodyResult = patch.TestBodyClass()
        self.assertEqual(clsBodyResult.patch, True)
          
        clsBeforeResult = patch.TestBeforeClass()
        self.assertEqual(clsBeforeResult.patch, True)
          
        clsAfterResult = patch.TestAfterClass()
        clsAfterResult.changePatchValue()
        self.assertEqual(clsAfterResult.patch, True)
          
    def tearDown(self):
        shutil.rmtree(self.testPackageDir)
        zipFile = os.path.join(self.sitePackagesDir, "PatchTestPackage.zip")
        os.remove(zipFile)
#         pass        
 
if __name__ == '__main__':
    unittest.main() 
