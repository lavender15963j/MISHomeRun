#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: DjangoUtil.py 9742 2017-02-08 01:01:19Z David $
#
# Copyright (c) 2015 Nuwa Information Co., Ltd, and individual contributors.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#
#   2. Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#
#   3. Neither the name of Nuwa Information nor the names of its contributors
#      may be used to endorse or promote products derived from this software
#      without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# $Author: David $ (last)
# $Date: 2017-02-08 09:01:19 +0800 (週三, 08 二月 2017) $
# $Revision: 9742 $
"""
Utilities for django.
"""

import time
import datetime

from Iuppiter.Util import extendUnique

def extendInstalledApps(settingsLocals, apps, key=None, addBefore=False):
    """
    Extend apps into settings.INSTALLED_APPS.
    INSTALLED_APPS is required existed in settings.

    @param settingsLocals locals() in settings.py.
    @param apps Apps tuple.
    @param key Reference key to insert apps.
    @param addBefore Insert apps before reference key or not.
    """
    installed = settingsLocals['INSTALLED_APPS']
    settingsLocals['INSTALLED_APPS'] = extendUnique(installed, apps,
                                                    referenceKey=key,
                                                    addBefore=addBefore)
                                                    
def extendSessionSerializer(settingsLocals, serializers, key=None, 
                            addBefore=False):
    """
    Extend apps into settings.SESSION_SERIALIZER.
    SESSION_SERIALIZER is required existed in settings.

    @param settingsLocals locals() in settings.py.
    @param serializers Serializer tuple.
    @param key Reference key to insert apps.
    @param addBefore Insert apps before reference key or not.
    """
    installed = settingsLocals.get('SESSION_SERIALIZER', None)
    
    if installed:
        settingsLocals['SESSION_SERIALIZER'] = extendUnique(installed, 
                                                            serializers,
                                                            referenceKey=key,
                                                            addBefore=addBefore)
    else:
        settingsLocals['SESSION_SERIALIZER'] = serializers
                                                    
def extendAuthenticationBackend(settingsLocals, backends, key=None, 
                                addBefore=False):
    """
    Extend apps into settings.AUTHENTICATION_BACKENDS.
    AUTHENTICATION_BACKENDS is required existed in settings.

    @param settingsLocals locals() in settings.py.
    @param backends Backends tuple.
    @param key Reference key to insert apps.
    @param addBefore Insert apps before reference key or not.
    """
    
    if 'AUTHENTICATION_BACKENDS' in settingsLocals:
        installed = settingsLocals['AUTHENTICATION_BACKENDS']
        settingsLocals['AUTHENTICATION_BACKENDS'] = extendUnique(installed, 
                                                                 backends,
                                                             referenceKey=key,
                                                            addBefore=addBefore)
    else:
        settingsLocals['AUTHENTICATION_BACKENDS'] = backends
    
def extendTemplateContextProcessors(settingsLocals, processors, key=None,
                                    addBefore=False):
    """
    Extend processors into settings.TEMPLATE_CONTEXT_PROCESSORS.

    @param settingsLocals locals() in settings.py.
    @param processors Template context processors tuple.
    @param key Reference key to insert processors.
    @param addBefore Insert processors before reference key or not.
    """
    p = settingsLocals.get('TEMPLATES', ())
    for templateSettings in p:

        if templateSettings['BACKEND'] == \
               'django.template.backends.django.DjangoTemplates':
            
            options = templateSettings.get('OPTIONS', ())
            contextProcessors = options.get('context_processors', ())
            options['context_processors'] = extendUnique(contextProcessors, 
                                                         processors,
                                                         referenceKey=key,
                                                         addBefore=addBefore)
            
def extendMiddlewareClasses(settingsLocals, classes, key=None, addBefore=False):
    """
    Extend classes into settings.MIDDLEWARE_CLASSES.

    @param settingsLocals locals() in settings.py.
    @param classes Middleware classes tuple.
    @param key Reference key to insert classes.
    @param addBefore Insert classes before reference key or not.
    """
    p = settingsLocals.get('MIDDLEWARE_CLASSES', ())
    settingsLocals['MIDDLEWARE_CLASSES'] = extendUnique(p, classes,
                                                        referenceKey=key,
                                                        addBefore=addBefore)

def extendTemplateDirs(settingsLocals, dirs, key=None, addBefore=False):
    """
    Extend classes into settings.TEMPLATE_DIRS.

    @param settingsLocals locals() in settings.py.
    @param classes TEMPLATES dirs list.
    @param key Reference key to insert classes.
    @param addBefore Insert classes before reference key or not.
    """
    p = settingsLocals.get('TEMPLATES', ())
    for templateSettings in p:
        if templateSettings['BACKEND'] == \
                   'django.template.backends.django.DjangoTemplates':
            templateDirs = templateSettings.get('DIRS', ())
            templateSettings['DIRS'] = extendUnique(dirs, templateDirs,
                                                    referenceKey=key,
                                                    addBefore=addBefore)


def extendDatabaseDefaults(settingsLocals, defaultValues):
    """
    Extend default key-value into settings.DATABASES.

    @param settingsLocals locals() in settings.py.
    @param defaultValues Key-value of database default dict.
    @param key Reference key to insert classes.
    @param addBefore Insert classes before reference key or not.
    """

    p = settingsLocals.get('DATABASES', ())
    defaultSettings = p.get('default', ())
    for key in defaultValues:
        defaultSettings.setdefault(key, defaultValues[key])

class Expiration(object):
    """
    Expiration datetime wrapper.
    """

    def __init__(self, expireMillisecond):
        """
        Constructor.

        @param expireMillisecond Milliseconds of expiration.
        """
        self.expireMillisecond = expireMillisecond
        self.expireDatetime = datetime.datetime.now() + \
            datetime.timedelta(milliseconds=self.expireMillisecond)

    def expired(self):
        """
        Is expired or not?

        @return True if it is expired.
        """
        return datetime.datetime.now() >= self.expireDatetime

class TemporaryKeyGenerator(object):
    """
    Temporary key generator to generate keys for temporary usage and clear it
    while expired.
    It also manages container's content, this generator will provide three
    functions to let you get/set/delete data for container.
    """

    def __init__(self, container, expireMillisecond=60000,
                 factory=lambda: str(time.clock())):
        """
        Constructor.

        @param container The container to store generated temporary key and
                         value.
        @param expireMillisecond Milliseconds of expiration.
        @param factory Key generation factory. It can be any callable thing.
        """
        from django.core.cache.backends.base import BaseCache
        
        super(TemporaryKeyGenerator, self).__init__()       

        self.container = container
        if isinstance(container, dict):
            def _get(k):
                v, exp = self.container[k]
                return None if exp.expired() else v
            self.get = _get

            def _set(k, v, exp):
                self.container[k] = (v, exp)
            self.set = _set

            def _del(k):
                del self.container[k]
            self.delete = _del
        elif isinstance(container, BaseCache):
            self.get = self.container.get

            def _set(k, v, exp):
                self.container.set(k, v, exp.expireMillisecond / 1000)
            self.set = _set

            self.delete = self.container.delete
        elif isinstance(container, list):
            def _get(k):
                for _k, _v, _exp in self.container:
                    if k == _k:
                        return None if _exp.expired() else _v
            self.get = _get

            def _set(k, v, exp):
                self.container.append((k, v, exp))
            self.set = _set

            def _delete(k):
                for i, (_k, _v, _exp) in enumerate(self.container):
                    if k == _k:
                        del self.container[i]
                        return
            self.delete = _delete
        else:
            NotImplemented('This type is not supported.')

        self.factory = factory
        self.expireMillisecond = expireMillisecond

    def generate(self, value, *args, **kws):
        """
        Generate temporary key and its expiration time.

        @param value The value you want to put.
        @param *args Arguments that will pass to factory.
        @param **kws Keyword arguments that will pass to factory.
        @return (key, expiration time)
        """
        key = self.factory(*args, **kws)
        exp = Expiration(self.expireMillisecond)

        self.set(key, value, exp)
        return (key, exp)

    def clear(self, criteria=500):
        """
        Clear expired data from given container which contains temporary key
        if the length of container over the maximum criteria.

        @param criteria Criteria.
        @return True if clear operation is done.
        """
        from django.core.cache.backends.base import BaseCache
        
        # Cache backend has its own expiration mechanism.
        if isinstance(self.container, BaseCache):
            return True

        size = len(self.container)
        if size >= criteria:
            if isinstance(self.container, dict):
                for key in self.container.keys():
                    if self.container[key][-1].expired():
                        del self.container[key]
            elif isinstance(self.container, list):
                i = size - 1
                for j in range(size):
                    item = self.container[i]
                    if item[-1].expired():
                        del self.container[i]
                    i -= 1
            else:
                raise NotImplementedError('This type is not supported.')

            return True
        else:
            return False

# https://gist.github.com/527113/307c2dec09ceeb647b8fa1d6d49591f3352cb034
def checkTableExists(table, cursor=None):
    """
    Check database table exists or not.

    @param table Table name.
    @return True if table exists.
    """
    try:
        if not cursor:
            from django.db import connection
            cursor = connection.cursor()
        if not cursor:
            raise Exception
        tables = connection.introspection.get_table_list(cursor)
    except:
        raise Exception("Unable to determine if the table '%s' exists" % table)
    else:
        return table in tables
