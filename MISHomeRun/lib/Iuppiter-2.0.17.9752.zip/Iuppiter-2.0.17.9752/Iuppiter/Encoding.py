#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: Encoding.py 9657 2016-05-03 18:30:26Z Bear $
#
# Copyright (c) 2016 Nuwa Information Co., Ltd, and individual contributors.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#
#   2. Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#
#   3. Neither the name of Nuwa Information nor the names of its contributors
#      may be used to endorse or promote products derived from this software
#      without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# $Author: Bear $ (last)
# $Date: 2016-05-04 02:30:26 +0800 (週三, 04 五月 2016) $
# $Revision: 9657 $
"""
Encoding related utilities.
"""

import codecs
import cStringIO as StringIO

def utf8(s):
    """
    Convert a string (UNICODE or ANSI) to a utf8 string.

    @param s String.
    @return UTF8 string.
    """
    info = codecs.lookup('utf8')
    try:
        out = StringIO.StringIO()
        srw = codecs.StreamReaderWriter(out,
                info.streamreader, info.streamwriter, 'strict')
        srw.write(s)
        return out.getvalue()
    except UnicodeError:
        # Try again by forcing convert to unicode type first.
        srw.write(_unicode(s, strict=True))
        return out.getvalue()
    finally:
        srw.close()
        out.close()

import locale

_UNICODE_TRY_ENCODINGS = (locale.getpreferredencoding(),)
# See #2758. for details.
if 'cp950' not in _UNICODE_TRY_ENCODINGS:
    _UNICODE_TRY_ENCODINGS = _UNICODE_TRY_ENCODINGS + ('cp950',)

def _unicode(s, strict=False, encodings=None, throw=True):
    """
    Force to UNICODE string (UNICODE type or string type with utf8 content).

    @param s String.
    @param strict If strict is True, we always return UNICODE type string, this
                  means it will ignore to try convert it to utf8 string.
    @param encodings Native encodings for decode. It will be tried to decode
                     string, try and error.
    @param throw Raise exception if it fails to convert string.
    @return UNICODE type string or utf8 string.
    """
    try:
        if isinstance(s, unicode):
            if strict:
                return s
            else:
                return utf8(s)
        else:
            return unicode(s, 'utf8')
    except: # For UNICODE, cp950...
        try:
            return unicode(s)
        except:
            if not encodings:
                encodings = _UNICODE_TRY_ENCODINGS

            for encoding in encodings:
                try:
                    return unicode(s, encoding)
                except:
                    pass
            else:
                if strict:
                    if throw:
                        raise
                    else:
                        return u''
                else:
                    try:
                        return str(s)
                    except:
                        if throw:
                            raise
                        else:
                            return u''
