#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: setup.py 9752 2017-02-17 08:40:46Z Bear $
#
# Copyright (c) 2017 Nuwa Information Co., Ltd, and individual contributors.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
#
#   1. Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.
#
#   2. Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in the
#      documentation and/or other materials provided with the distribution.
#
#   3. Neither the name of Nuwa Information nor the names of its contributors
#      may be used to endorse or promote products derived from this software
#      without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# $Author: Bear $ (last)
# $Date: 2017-02-17 16:40:46 +0800 (週五, 17 二月 2017) $
# $Revision: 9752 $

# Eat our own dog food.
from Iuppiter.DistUtil import setup

extraRequirements = [
    # Cannot install django 1.8 through setuptools.setup.
    # Have created ticket on django.
    # ticket: https://code.djangoproject.com/ticket/25360
    'pip install "Django>=1.8,<1.9"',
]

from sys import platform as _platform

# There is no gui in Linux environment and we only use pycrust with wxpython.
# Moreover, wxpython cannot be installed in Linux, so it is not required in
# Linux environment.
# Possible platform value: http://stackoverflow.com/questions/446209/
# possible-values-from-sys-platform
if _platform == "win32" or _platform == "darwin":
    wxpythonRequire = ("pip install --upgrade --trusted-host wxpython.org "
                       "--pre -f http://wxpython.org/Phoenix/snapshot-builds/ "
                       "wxPython_Phoenix")
    extraRequirements.append(wxpythonRequire)
    
setup(
    'Iuppiter',
    description='Utilities for all Nuwa company developed projects.',
    version='%s.%s' % ('2.0.17', "$Revision: 9752 $"[11:-2]),
    license='New BSD License',
    author='Nuwa Information Co., Ltd',
    author_email='bear@nuwainfo.com',
    url='http://www.nuwainfo.com/',
    zip_safe=False,
    extraRequirements=extraRequirements,
)
